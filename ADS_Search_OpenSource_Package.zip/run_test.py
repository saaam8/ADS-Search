
import numpy as np
from ADS_Search import ADS_Search
import time

x, y, z = 1000, 1000, 10
data = np.zeros((x, y, z))
for i in range(x):
    for j in range(y):
        for k in range(z):
            data[i, j, k] = i - j + np.random.normal(0, 8) + k * 12

ads = ADS_Search(divisions=20)
divs = ads.partition(data)

for idx, d in enumerate(divs):
    steering = "asc-horizontal" if np.mean(d) < 0 else "desc-vertical"
    start = time.time()
    val, pos = ads.search(d, steering)
    end = time.time()
    print(f"Division {idx+1} | Steering: {steering} | Max: {val:.2f} at {pos} | Time: {end - start:.3f}s")
