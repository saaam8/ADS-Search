
# ADS-Search

ADS-Search (Adaptive Divisional Search) is a modular, dynamic search algorithm optimized for massive, high-dimensional datasets.

## Features
- Division-based partitioning
- Dual steering (horizontal/vertical)
- Ascending & descending pattern logic
- Adaptive feedback and fallback
- Tested on 10M+ data points

## Usage
Run:
```bash
python run_test.py
```
