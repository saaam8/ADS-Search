
import numpy as np

class ADS_Search:
    def __init__(self, divisions=10):
        self.divisions = divisions

    def partition(self, data):
        return np.array_split(data, self.divisions, axis=0)

    def search(self, division, steering):
        max_val = None
        best_pos = (0, 0, 0)
        for z in range(division.shape[2]):
            for x in (range(division.shape[0]) if "asc" in steering else reversed(range(division.shape[0]))):
                for y in (range(division.shape[1]) if "horizontal" in steering else reversed(range(division.shape[1]))):
                    val = division[x, y, z]
                    if max_val is None or val > max_val:
                        max_val = val
                        best_pos = (x, y, z)
        return max_val, best_pos
